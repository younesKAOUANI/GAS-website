// This file is required for Vercel deployments.
// You can add static assets here if needed.
